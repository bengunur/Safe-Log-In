package com.bengu_nur_oz.safe_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
