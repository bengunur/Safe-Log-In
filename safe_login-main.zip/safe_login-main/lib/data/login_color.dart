enum LoginColor {
  yellow('yellow'),
  green('green'),
  blue('blue'),
  red('red');

  const LoginColor(this.text);
  final String text;
}
