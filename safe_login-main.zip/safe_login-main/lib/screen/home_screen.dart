import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../util/constants.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _username = '';
  String _selectedColor = '';
  double _selectedSliderValue = 0.0;

  @override
  void initState() {
    super.initState();
    _getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: appGradientBackground,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      onPressed: () {
                        Navigator.pop<bool>(context, true);
                      },
                      icon: const Icon(
                        Icons.exit_to_app,
                        size: 35,
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Hoşgeldin, $_username',
                        style: Theme.of(context).textTheme.headlineLarge,
                      ),
                      Text(
                        'Seçtiğin renk: $_selectedColor',
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      Text(
                        'Seçtiğin deger: $_selectedSliderValue',
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _getData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('username');
    final loginColor = prefs.getString('loginColor');
    final currentSliderValue = prefs.getDouble('currentSliderValue');

    setState(() {
      _username = username ?? '';
      _selectedColor = loginColor ?? '';
      _selectedSliderValue = currentSliderValue ?? 0;
    });
  }
}
