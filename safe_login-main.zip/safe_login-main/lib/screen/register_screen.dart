import 'package:flutter/material.dart';

import '../util/constants.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register'),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: appGradientBackground,
        child: const Center(
          child: Text('Register Screen'),
        ),
      ),
    );
  }
}
