import 'package:flutter/material.dart';
import 'package:safe_login/data/login_color.dart';
import 'package:safe_login/screen/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../util/constants.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? _username;
  String? _password;
  bool _isLogin = true;
  bool _isObscureText = true;
  LoginColor _loginColor = LoginColor.yellow;
  double _currentSliderValue = 0.0;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size; // cihaz boyutunu al
    final height = size.height; // cihaz yükselliklerini al
    final width = size.width; // cihaz genişliğini al
    final paddingHorizontal = width * 0.08; // cihaz genişliğinin 8% ini kullan
    final topSpace = height * 0.08; // cihaz yükselliklerinin 8% ini kullan
    final elementSpace = height * 0.02; // cihaz yükselliklerinin 2% sini kullan

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: appGradientBackground,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: topSpace),
              Text(_isLogin ? 'Giriş Yapın' : 'Kayıt Olun',
                  style: Theme.of(context).textTheme.headlineLarge!.copyWith(
                        fontWeight: FontWeight.bold,
                      )),
              SizedBox(height: elementSpace),
              _isLogin
                  ? const Icon(Icons.lock_person,
                      size: 100, color: Colors.purple)
                  : const Icon(Icons.edit_note,
                      size: 100, color: Colors.purple),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: paddingHorizontal, vertical: elementSpace),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        initialValue: _username,
                        decoration: InputDecoration(
                          labelText: 'Kullanıcı Adını Giriniz',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        validator: (value) {
                          if (value == null ||
                              value.isEmpty ||
                              value.trim().length <= 1) {
                            return 'Lütfen geçerli bir kullanıcı adı giriniz.';
                          }
                          return null;
                        },
                        onSaved: (newValue) {
                          _username = newValue;
                        },
                      ),
                      SizedBox(height: elementSpace),
                      TextFormField(
                        initialValue: _password,
                        obscureText: _isObscureText,
                        decoration: InputDecoration(
                          labelText: 'Şifrenizi Giriniz',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(_isObscureText
                                ? Icons.visibility
                                : Icons.visibility_off),
                            onPressed: () {
                              setState(() {
                                _isObscureText = !_isObscureText;
                              });
                            },
                          ),
                        ),
                        validator: (value) {
                          if (value == null ||
                              value.isEmpty ||
                              value.trim().length <= 1) {
                            return 'Lütfen geçerli bir şifre giriniz.';
                          }
                          return null;
                        },
                        onSaved: (newValue) {
                          _password = newValue;
                        },
                      ),
                      SizedBox(height: elementSpace),
                      Text(
                        'Renk Seçin',
                        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                              color: Theme.of(context).colorScheme.primary,
                            ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: Theme.of(context).colorScheme.primary,
                              width: 2),
                        ),
                        child: Row(children: [
                          Expanded(
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 2, right: 1, top: 2, bottom: 2),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        width: _loginColor == LoginColor.yellow
                                            ? 4
                                            : 0),
                                    color: Colors.yellow,
                                  ),
                                  height: 50,
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  _loginColor = LoginColor.yellow;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 1, vertical: 2),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        width: _loginColor == LoginColor.green
                                            ? 4
                                            : 0),
                                    color: Colors.green,
                                  ),
                                  height: 50,
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  _loginColor = LoginColor.green;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 1, vertical: 2),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        width: _loginColor == LoginColor.blue
                                            ? 4
                                            : 0),
                                    color: Colors.blue,
                                  ),
                                  height: 50,
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  _loginColor = LoginColor.blue;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 1, right: 2, top: 2, bottom: 2),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        width: _loginColor == LoginColor.red
                                            ? 4
                                            : 0),
                                    color: Colors.red,
                                  ),
                                  height: 50,
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  _loginColor = LoginColor.red;
                                });
                              },
                            ),
                          ),
                        ]),
                      ),
                      SizedBox(height: elementSpace),
                      Text(
                        'Numaranızı Seçin',
                        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                              color: Theme.of(context).colorScheme.primary,
                            ),
                      ),
                      Slider(
                        inactiveColor: Colors.purple.shade100,
                        value: _currentSliderValue,
                        max: 40.0,
                        divisions: 8,
                        label: _currentSliderValue.round().toString(),
                        onChanged: (value) {
                          setState(() {
                            _currentSliderValue = value;
                          });
                        },
                      ),
                      SizedBox(height: elementSpace),
                      ElevatedButton(
                        onPressed: () {
                          _isLogin ? _login() : _register();
                        },
                        child: Text(
                          _isLogin ? 'Giriş Yap' : 'Kayıt Ol',
                          style: const TextStyle(
                            color: Colors.purple,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(height: elementSpace),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            _isLogin = !_isLogin;
                          });
                        },
                        child: Text(
                          _isLogin
                              ? 'Hesabınız Yok mu? Kayıt Olun...'
                              : 'Hesabınız Var mı? Giriş Yapın...',
                          style: const TextStyle(
                            color: Colors.purple,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void _login() async {
    // Your login logic here
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
    }

    if (_username == null ||
        _password == null ||
        _password!.trim().length <= 1) {
      return;
    }

    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('username');
    final password = prefs.getString('password');
    final currentSliderValue = prefs.getDouble('currentSliderValue');
    final loginColor = prefs.getString('loginColor');

    if (_username != username ||
        _password != password ||
        _currentSliderValue != currentSliderValue ||
        _loginColor.text != loginColor) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content:
                  Text('Girdiğiniz bilgiler yanlış.\nLütfen tekrar deneyin.')),
        );
      }
      return;
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Giriş başarılı.')),
      );
    }

    _gotoLoginScreen();
  }

  void _register() async {
    // Your registration logic here
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
    }

    if (_username == null || _password == null) {
      return;
    }

    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', _username ?? '');
    await prefs.setString('password', _password ?? '');
    await prefs.setDouble('currentSliderValue', _currentSliderValue);
    await prefs.setString('loginColor', _loginColor.text);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kayıt başarılı.')),
      );
    }

    setState(() {
      _formKey.currentState!.reset();
      _isLogin = true;
    });
  }

  Future<void> _gotoLoginScreen() async {
    final isPop = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (context) => const HomeScreen()),
    );

    if (isPop ?? false) {
      setState(() {
        _formKey.currentState!.reset();
      });
    }
  }
}
