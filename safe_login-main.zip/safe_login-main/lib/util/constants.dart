import 'package:flutter/material.dart';

final appGradientBackground = BoxDecoration(
  gradient: LinearGradient(
    colors: [
      Colors.deepPurple.shade300,
      Colors.purple.shade100,
      Colors.white,
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  ),
);
